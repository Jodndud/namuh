---
description: Run code linting and formatting checks
---

Run linting and formatting checks across the codebase using `bash lint`.

Use the 'lint-agent' sub-agent to execute linting and report results in a clear, actionable format.

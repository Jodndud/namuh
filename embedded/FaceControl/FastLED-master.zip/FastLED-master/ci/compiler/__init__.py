"""
FastLED Compiler Module

High-performance compilation system built on proven Python compiler API.
"""

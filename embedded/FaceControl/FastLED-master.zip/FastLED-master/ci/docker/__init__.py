"""Docker build utilities for FastLED PlatformIO compilation."""
